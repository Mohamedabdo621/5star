import 'package:flutter/material.dart';

void main() {
  runApp(const AlZakaAlNajmyApp());
}

class AlZakaAlNajmyApp extends StatelessWidget {
  const AlZakaAlNajmyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الذكاء النجمي',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE0F7FA),
      appBar: AppBar(
        title: const Text('الذكاء النجمي'),
      ),
      body: const Center(
        child: Text(
          'مرحبًا بك في الذكاء النجمي!',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
